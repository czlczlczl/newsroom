var a = [1,2,3];
var b = [4,5,6,7];
 console.log(b.slice(2,3));